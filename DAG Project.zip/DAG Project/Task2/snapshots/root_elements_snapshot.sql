-- snapshots/root_elements_snapshot.sql
{{ config(
    materialized='snapshot',
    target_schema='chiranjeevi_chirtha',
    unique_key='root_element_id',
    strategy='timestamp',
    updated_at='snapshot_date',
    unique_key='root_element_id'
) }}

WITH raw_root_elements AS (
    SELECT * FROM dev.RAW_TIPICO_TOP_EVENTS
)

SELECT
    raw_root_elements.*,
    CURRENT_TIMESTAMP() AS snapshot_date
FROM raw_root_elements;

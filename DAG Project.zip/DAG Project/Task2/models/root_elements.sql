-- models/root_elements.sql
WITH raw_root_elements AS (
    SELECT * FROM dev.RAW_TIPICO_TOP_EVENTS
)

SELECT
    *
FROM raw_root_elements;

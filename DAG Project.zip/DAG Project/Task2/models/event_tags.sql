-- models/event_tags.sql
WITH raw_event_tags AS (
    SELECT
        x.eventTag
    FROM dev.RAW_TIPICO_TOP_EVENTS,
    LATERAL FLATTEN(input => dev.RAW_TIPICO_TOP_EVENTS.x) AS x
)

SELECT
    *
FROM raw_event_tags;

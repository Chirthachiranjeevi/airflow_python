-- models/markets.sql
WITH raw_markets AS (
    SELECT
        x.markets
    FROM dev.RAW_TIPICO_TOP_EVENTS,
    LATERAL FLATTEN(input => dev.RAW_TIPICO_TOP_EVENTS.x) AS x
)

SELECT
    *
FROM raw_markets;

-- models/participants.sql
WITH raw_participants AS (
    SELECT
        x.participants
    FROM dev.RAW_TIPICO_TOP_EVENTS,
    LATERAL FLATTEN(input => dev.RAW_TIPICO_TOP_EVENTS.x) AS x
)

SELECT
    *
FROM raw_participants;

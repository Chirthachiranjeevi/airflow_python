-- models/group.sql
WITH raw_group AS (
    SELECT
        x.group
    FROM dev.RAW_TIPICO_TOP_EVENTS,
    LATERAL FLATTEN(input => dev.RAW_TIPICO_TOP_EVENTS.x) AS x
)

SELECT
    *
FROM raw_group;

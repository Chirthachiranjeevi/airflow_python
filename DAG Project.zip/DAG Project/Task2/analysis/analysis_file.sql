-- analysis/analysis_file.sql
-- Your analysis queries go here
SELECT
    *
FROM
    {{ ref('root_elements') }}
WHERE
    column_name = 'some_condition';

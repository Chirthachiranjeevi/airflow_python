from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import requests
import pandas as pd
from sqlalchemy import create_engine

# Define the Redshift credentials
redshift_credentials = {
    'host': 'manual-dwh-candidatetests.258845600139.us-east-1.redshift-serverless.amazonaws.com',
    'port': 5439,
    'database': 'dev',
    'username': 'chiranjeevi_chirtha',
    'password': 'hduwed6211JDEWJDFUE!'
}

# Define the DAG
default_args = {
    'owner': 'data_engineer',
    'depends_on_past': False,
    'start_date': datetime(2024, 2, 14),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'tipico_api_dag',
    default_args=default_args,
    description='DAG to call Tipico API and persist results in a table',
    schedule_interval=timedelta(minutes=10),
)

# Define the function to call the Tipico API and persist results
def endpoint_tipico_api(**kwargs):
    tipico_api_url = (
        "https://sportsbook-nj.tipico.us/v1/pds/fe/top-events?"
        "lang=en&licenseId=US-NJ&marketTypes=standard%2Chole-x-2-ball-1x2%2Cwinner%2Covertime-1x2%2Cgames-more-less-than%2Csection-win%2Chandicap%2Cpoints-more-less-than%2Chandicap-incl-overtime-and-penalties%2Ctotal-incl-overtime-and-penalties%2Cstandard-full%2Ctotal%2Chead-to-head%2Cfree-text%2Cdraw-no-bet"
    )

    # Use a session to improve performance with multiple requests
    with requests.Session() as session:
        response = session.get(tipico_api_url)
        response.raise_for_status()
        data = response.json()

    # Assuming 'SUPER' object is present in the API response
    super_object = data.get('SUPER', [])

    # Transform data to DataFrame
    df = pd.DataFrame(super_object)

    # Persist data to RAW_TIPICO_TOP_EVENTS table in Redshift
    engine = create_engine(
        f"postgresql://{redshift_credentials['username']}:{redshift_credentials['password']}@{redshift_credentials['host']}:{redshift_credentials['port']}/{redshift_credentials['database']}"
    )
    df.to_sql('RAW_TIPICO_TOP_EVENTS', con=engine, if_exists='replace', index=False, schema='chiranjeevi_chirtha')

# Define the operators
endpoint_tipico_api_task = PythonOperator(
    task_id='endpoint_tipico_api',
    python_callable=endpoint_tipico_api,
    provide_context=True,
    dag=dag,
)

# Set task dependencies
endpoint_tipico_api_task

if __name__ == "__main__":
    dag.cli()

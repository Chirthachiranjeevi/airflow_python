# Tipico API Airflow DAG Project

This project contains an Airflow DAG to automate the task of calling the Tipico API and persisting the results in a table.

## Project Structure


- **dags/**: Contains the Airflow DAG script.
- **scripts/**: Contains the `requirements.txt` file with project dependencies.
- **README.md**: Project documentation.

## Setup

1. Install the required Python packages:

   ```bash
   pip install -r scripts/requirements.txt
   
1)Ensure that you have set up Apache Airflow in your environment.

Create a Python virtual environment and install the required dependencies using the requirements.txt file:

2)Run the Airflow DAG using the Airflow CLI:
airflow dags trigger tipico_api_dag

